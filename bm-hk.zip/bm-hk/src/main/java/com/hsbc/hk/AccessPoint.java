package com.hsbc.hk;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

public class AccessPoint {
    public AuthenticationService createInstance() {
        // @TODO implement this method to return a concrete instance of @see AuthenticationService interface implementation
        throw new NotImplementedException();
    }
}
