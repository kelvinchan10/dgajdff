package com.hsbc.hk;

public interface Role {
    String name();
}
