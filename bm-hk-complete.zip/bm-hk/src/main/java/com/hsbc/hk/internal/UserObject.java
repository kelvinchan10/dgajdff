package com.hsbc.hk.internal;

import com.hsbc.hk.Role;
import com.hsbc.hk.User;

import java.util.HashSet;
import java.util.Set;

class UserObject implements UserInternal {
    private String name = null;
    private String password = null;
    private Set<Role> roles = null;

    public UserObject(String name, String password) {
        this.name = name;
        this.password = password;
        this.roles = new HashSet<>();
    }

    @Override
    public String name() {
        return this.name;
    }

    @Override
    public boolean authenticated(String password) {
        return this.password.equals(password);
    }

    @Override
    public Set<Role> getRoles() {
        return roles;
    }

    @Override
    public boolean equals(Object o) {
        return name.equals(((User)o).name());
    }
    @Override
    public int hashCode() {
        return name.hashCode();
    }
}
