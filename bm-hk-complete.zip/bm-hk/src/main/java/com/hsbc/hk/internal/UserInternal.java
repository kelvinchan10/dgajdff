package com.hsbc.hk.internal;

import com.hsbc.hk.Role;
import com.hsbc.hk.User;

import java.util.Set;

interface UserInternal extends User {
    boolean authenticated(String password);
    Set<Role> getRoles();

}
