package com.hsbc.hk.internal;

import com.hsbc.hk.Role;

class RoleObject implements Role {
    private String name = null;

    public RoleObject(String name) {
        this.name = name;
    }

    @Override
    public String name() {
        return name;
    }

    @Override
    public boolean equals(Object o) {
        return name.equals(((Role)o).name());
    }
    @Override
    public int hashCode() {
        return name.hashCode();
    }
}
