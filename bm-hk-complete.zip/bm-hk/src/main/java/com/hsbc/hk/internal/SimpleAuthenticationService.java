package com.hsbc.hk.internal;

import com.hsbc.hk.AuthenticationService;
import com.hsbc.hk.Role;
import com.hsbc.hk.Token;
import com.hsbc.hk.User;

import java.util.*;

// class to implement the Authentication Service interface.
// This is the very implementation exepcted to the be simple.
// In memory storage for all the information and extracted to be in AuthenticationStorage object.
// Internal interface and private-package accesses have been used in the implementation
// to limit the access of clients on the objects returned.
// A more complicated implementation may be needed if multithreaded access is necessary.
public class SimpleAuthenticationService implements AuthenticationService {
    private HashMap<String, UserInternal> nameUserMap = null;
    private HashMap<String, Role> nameRoleMap = null;
    private HashMap<TokenInternal, UserInternal> tokenUserMap = null;



    public SimpleAuthenticationService() {
        this(new AuthenticationStorage());
    }

    public SimpleAuthenticationService(AuthenticationStorage storage) {
        this.nameUserMap = storage.getNameUserMap();
        this.nameRoleMap = storage.getNameRoleMap();
        this.tokenUserMap = storage.getTokenUserMap();
    }

    @Override
    public User createUser(String name, String password) {
        if (name == null || password == null || name.isEmpty() || password.isEmpty()) {
            throw new IllegalArgumentException("Name and password parameters should have valid values!");
        }
        if (nameUserMap.containsKey(name)) {
            throw new IllegalArgumentException("Same user existed!");
        }
        UserInternal newUser = new UserObject(name, password);
        nameUserMap.put(name, newUser);
        return newUser;
    }

    @Override
    public void deleteUser(User user) {
        String name = user.name();
        if (!nameUserMap.containsKey(name)) {
            throw new IllegalArgumentException("User does not exist!");
        }
        nameUserMap.remove(name);


    }

    @Override
    public Optional<User> findUser(String name) {
        UserInternal userObj = nameUserMap.get(name);
        return Optional.ofNullable(userObj);
    }

    @Override
    public Role createRole(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name parameter should have a valid value!");
        }

        if (nameRoleMap.containsKey(name)) {
            throw new IllegalArgumentException("Same role existed!");
        }
        Role newRole = new RoleObject(name);
        nameRoleMap.put(name, newRole);
        return newRole;
    }

    @Override
    public Optional<Role> findRole(String name) {
        Role roleObj = nameRoleMap.get(name);
        return Optional.ofNullable(roleObj);
    }

    @Override
    public void deleteRole(Role role) {
        String name = role.name();
        if (!nameRoleMap.containsKey(name)) {
            throw new IllegalArgumentException("Role does not exist!");
        }
        nameRoleMap.remove(name);

    }

    @Override
    public void addRoleToUser(Role role, User user) {
        if (role == null || user == null) {
            throw new IllegalArgumentException("Role and user parameters should have valid values!");
        }


        String userName = user.name();
        String roleName = role.name();
        if (!(nameUserMap.containsKey(userName) && nameRoleMap.containsKey(roleName))) {
            throw new IllegalArgumentException("User or role do not exist!");
        }
        nameUserMap.get(userName).getRoles().add(role);
    }

    @Override
    public Token authenticate(String username, String password, String salt) {
        UserInternal user = nameUserMap.get(username);
        if (user == null) {
            throw new IllegalArgumentException("User does not exist!");
        }
        if (!user.authenticated(password)) {
            return null;
        }
        String hashValue = password+salt;
        TokenObject tokenObj = new TokenObject(hashValue);
        tokenUserMap.put(tokenObj, user);

        return tokenObj;
    }

    @Override
    public void invalidate(Token token) {
        if (!tokenUserMap.containsKey(token)) {
            throw new IllegalArgumentException("Invalid token!");
        }

        tokenUserMap.remove(token);
    }

    @Override
    public boolean checkRole(Token token, Role role) {
        if (role == null) {
            throw new IllegalArgumentException("Role parameter should have a valid value!");
        }

        String roleName = role.name();
        if (!(tokenUserMap.containsKey(token) && nameRoleMap.containsKey(roleName))) {
            throw new IllegalArgumentException("Invalid token or role not existed!");
        }

        UserInternal user = tokenUserMap.get(token);
        return user.getRoles().contains(role);
    }

    @Override
    public Set<Role> getAllRoles(Token token) {
        return new HashSet<>(nameRoleMap.values());
    }
}
