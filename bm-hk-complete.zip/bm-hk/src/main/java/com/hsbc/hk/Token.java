package com.hsbc.hk;

public interface Token {
}
