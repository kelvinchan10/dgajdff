package com.hsbc.hk;

public interface User {
    String name();
}
