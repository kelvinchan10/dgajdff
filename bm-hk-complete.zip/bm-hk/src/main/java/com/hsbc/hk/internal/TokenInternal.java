package com.hsbc.hk.internal;

import com.hsbc.hk.Token;

interface TokenInternal extends Token {
    String getHashValue();
}
