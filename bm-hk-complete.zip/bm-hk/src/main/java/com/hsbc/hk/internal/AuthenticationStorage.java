package com.hsbc.hk.internal;

import com.hsbc.hk.Role;

import java.util.HashMap;


class AuthenticationStorage {
    private HashMap<TokenInternal, UserInternal> tokenUserMap = null;
    private HashMap<String, Role> nameRoleMap = null;
    private HashMap<String, UserInternal> nameUserMap = null;

    public AuthenticationStorage() {
        tokenUserMap = new HashMap<>();
        nameUserMap = new HashMap<>();
        nameRoleMap = new HashMap<>();
    }

    public HashMap<TokenInternal, UserInternal> getTokenUserMap() {
        return tokenUserMap;
    }

    public HashMap<String, Role> getNameRoleMap() {
        return nameRoleMap;
    }

    public HashMap<String, UserInternal> getNameUserMap() {
        return nameUserMap;
    }

}
