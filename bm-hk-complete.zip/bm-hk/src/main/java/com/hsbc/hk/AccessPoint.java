package com.hsbc.hk;

import com.hsbc.hk.internal.SimpleAuthenticationService;

public class AccessPoint {
    private static AuthenticationService instance = new SimpleAuthenticationService();
    public AuthenticationService createInstance() {
        return instance;
    }
}
