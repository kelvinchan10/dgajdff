package com.hsbc.hk.internal;

class TokenObject implements TokenInternal {
    private String hashValue = null;

    public TokenObject(String hashValue) {
        this.hashValue = hashValue;
    }

    @Override
    public String getHashValue() {
        return this.hashValue;
    }

    @Override
    public int hashCode() {
        return this.hashValue.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return this.hashValue.equals(((TokenInternal)obj).getHashValue());
    }
}
