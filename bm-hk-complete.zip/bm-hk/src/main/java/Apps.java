import com.hsbc.hk.*;

// Sample user application
public class Apps {
    public static void main(String... args) {
        AccessPoint ap = new AccessPoint();
        AuthenticationService service = ap.createInstance();
        User userTom = service.createUser("Tom", "tomtom");
        User userSam = service.createUser("Sam", "samsam");
        Role roleAdmin = service.createRole("Admin");
        service.addRoleToUser(roleAdmin, userSam);
        Token tokenSam = service.authenticate("Sam", "samsam", "3333");
        Token tokenTom = service.authenticate("Tom", "tomtom", "333553");
        System.out.println("Is Sam Admin? " + service.checkRole(tokenSam, roleAdmin));
        System.out.println("Is Tom Admin? " + service.checkRole(tokenTom, roleAdmin));
        service.invalidate(tokenSam);
        try {
            service.checkRole(tokenSam, roleAdmin);
        } catch (IllegalArgumentException e) {
            System.out.println("Access token for Sam after invalidation: " + e.getMessage());
        }

    }

}
