package com.hsbc.hk.internal;

import static org.junit.jupiter.api.Assertions.*;

class RoleObjectTest {
    private RoleObject target = null;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        target = new RoleObject("Admin");
    }

    @org.junit.jupiter.api.Test
    void testName() {
        assertEquals("Admin", target.name());
        assertNotEquals("User", target.name());
    }


    @org.junit.jupiter.api.Test
    void testEquals() {

        assertTrue(target.equals(new RoleObject("Admin")));
        assertFalse(target.equals(new RoleObject("User")));
    }

    @org.junit.jupiter.api.Test
    void testHashCode() {
        assertEquals(new RoleObject("Admin").hashCode(), target.hashCode());
        assertNotEquals(new RoleObject("User").hashCode(), target.hashCode());
    }
}