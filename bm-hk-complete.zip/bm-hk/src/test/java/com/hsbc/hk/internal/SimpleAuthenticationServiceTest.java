package com.hsbc.hk.internal;

import com.hsbc.hk.Role;
import com.hsbc.hk.Token;
import com.hsbc.hk.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.util.HashMap;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

class SimpleAuthenticationServiceTest {
    private AuthenticationStorage storage;

    private SimpleAuthenticationService target = null;

    @BeforeEach
    void setup() {
        storage = new AuthenticationStorage();
        populateRoleData(storage, new String[]{"Role1", "Role2", "Role3", "Role4", "Role5"});
        populateUserData(storage, new String[][]{{"Peter", "123"}, {"John", "456"}, {"Susan", "ooo"}, {"Ken", "jjj"}});
        populateUserRoleData(storage, new String[][]{{"Peter", "Role1"}, {"John", "Role2", "Role5"}, { "Susan", "Role3", "Role4", "Role5"}, {"Ken", "Role1", "Role4"}});

        target = new SimpleAuthenticationService(storage);
    }

    @Test
    void createUser() {
        assertThrows(IllegalArgumentException.class, ()->{target.createUser("Peter", "123456");});
        assertThrows(IllegalArgumentException.class, ()->{target.createUser("", "");});
        assertThrows(IllegalArgumentException.class, ()->{target.createUser("Tom", "");});
        assertThrows(IllegalArgumentException.class, ()->{target.createUser(null, null);});
        User user = target.createUser("Tom", "12345678");
        assertEquals("Tom", user.name());
    }

    @Test
    void deleteUser() {
        UserInternal user1 = new UserObject("Tom", "ppp");
        assertThrows(IllegalArgumentException.class, ()->{target.deleteUser(user1);});
        UserInternal user2 = new UserObject("Peter", "123456");
        target.deleteUser(user2);
        assertThrows(IllegalArgumentException.class, ()->{target.deleteUser(user2);});
    }

    @Test
    void findUser() {
        assertFalse(target.findUser("Tom").isPresent());
        assertTrue(target.findUser("Susan").isPresent());
        assertEquals("Susan",target.findUser("Susan").get().name());
    }

    @Test
    void createRole() {
        assertThrows(IllegalArgumentException.class, ()->{target.createRole("Role2");});
        assertThrows(IllegalArgumentException.class, ()->{target.createRole("");});
        assertThrows(IllegalArgumentException.class, ()->{target.createRole(null);});
        Role role = target.createRole("Role7");
        assertEquals("Role7", role.name());
    }

    @Test
    void findRole() {
        assertFalse(target.findRole("Role8").isPresent());
        assertTrue(target.findRole("Role3").isPresent());
        assertEquals("Role3",target.findRole("Role3").get().name());
    }

    @Test
    void deleteRole() {
        Role role1 = new RoleObject("Role7");
        assertThrows(IllegalArgumentException.class, ()->{target.deleteRole(role1);});
        Role role2 = new RoleObject("Role3");
        target.deleteRole(role2);
        assertThrows(IllegalArgumentException.class, ()->{target.deleteRole(role2);});
    }

    @Test
    void addRoleToUser() {
        assertThrows(IllegalArgumentException.class, ()->{target.addRoleToUser(null, null);});
        UserInternal user1 = new UserObject("Tom", "ppp");
        Role role1 = new RoleObject("Role7");
        assertThrows(IllegalArgumentException.class, ()->{target.addRoleToUser(role1, user1);});
        UserInternal user2 = new UserObject("Susan", "ooo");
        Role role2 = new RoleObject("Role2");
        target.addRoleToUser(role2, user2);

    }

    @Test
    void authenticate() {
        assertThrows(IllegalArgumentException.class, ()->{target.authenticate(null, null, null);});
        assertThrows(IllegalArgumentException.class, ()->{target.authenticate("Tom", "ppp", "1213");});
        assertNull(target.authenticate("John", "ppp", "1213"));
        Token token = target.authenticate("John","456","334");
        assertNotNull(token);
    }

    @Test
    void invalidate() {
        Token token1 = target.authenticate("John","456","334");
        assertNotNull(token1);
        Token token2 = target.authenticate("John","456","3340");
        assertNotNull(token2);
        Role role=new RoleObject("Role2");
        assertTrue(target.checkRole(token1,role));
        target.invalidate(token1);
        assertThrows(IllegalArgumentException.class, ()->{target.checkRole(token1,role);});
        assertTrue(target.checkRole(token2,role));

    }

    @Test
    void checkRole() {
        Token token1 = target.authenticate("John","456","334");
        assertNotNull(token1);
        Role role1=new RoleObject("Role2");
        assertTrue(target.checkRole(token1, role1));
        Role role2=new RoleObject("Role3");
        assertFalse(target.checkRole(token1, role2));
        Token token2 = target.authenticate("Susan","ooo","334");
        assertNotNull(token2);
        assertFalse(target.checkRole(token2, role1));
        assertTrue(target.checkRole(token2, role2));
        Role role3=new RoleObject("Role8");
        assertThrows(IllegalArgumentException.class, ()->{target.checkRole(token2, role3);});

    }

    @Test
    void getAllRoles() {
        Token token1 = target.authenticate("John","456","334");
        Set<Role> roles1 =  target.getAllRoles(token1);
        assertTrue(checkRolePresent(new String[]{"Role2","Role5"}, roles1));
        Token token2 = target.authenticate("Ken","jjj","32234");
        Set<Role> roles2 =  target.getAllRoles(token2);
        assertTrue(checkRolePresent(new String[]{"Role1", "Role4"}, roles2));
    }

    private void populateRoleData(AuthenticationStorage storage, String[] roles) {
        HashMap<String, Role> roleStorage = storage.getNameRoleMap();
        for (String role: roles) {
            roleStorage.put(role, new RoleObject(role));
        }
    }

    private void populateUserData(AuthenticationStorage storage, String[][] users) {
        HashMap<String, UserInternal> userStorage = storage.getNameUserMap();
        for (String[] user: users) {
            userStorage.put(user[0], new UserObject(user[0],user[1]));
        }
    }

    private void populateUserRoleData(AuthenticationStorage storage, String[][] userRoles) {
        HashMap<String, UserInternal> userStorage = storage.getNameUserMap();
        HashMap<String, Role> roleStorage = storage.getNameRoleMap();
        for (String[] userRole: userRoles) {
            UserInternal user = userStorage.get(userRole[0]);
            for (int i=1;i<userRole.length;i++) {
                Role  role = roleStorage.get(userRole[i]);
                user.getRoles().add(role);
            }
        }
    }

    private boolean checkRolePresent(String[] expected, Set<Role> roles) {
        for (String role: expected) {
            Role roleObj = new RoleObject(role);
            if (!roles.contains(roleObj)) {
                return false;
            }
        }

        return true;
    }

}