package com.hsbc.hk.internal;

import static org.junit.jupiter.api.Assertions.*;

class TokenObjectTest {
    private TokenObject target = null;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        target = new TokenObject("a77HH_");
    }

    @org.junit.jupiter.api.Test
    void testName() {
        assertEquals("a77HH_", target.getHashValue());
        assertNotEquals("jj", target.getHashValue());
    }


    @org.junit.jupiter.api.Test
    void testEquals() {

        assertTrue(target.equals(new TokenObject("a77HH_")));
        assertFalse(target.equals(new TokenObject("jjja")));
    }

    @org.junit.jupiter.api.Test
    void testHashCode() {
        assertEquals(new TokenObject("a77HH_").hashCode(), target.hashCode());
        assertNotEquals(new TokenObject("sss").hashCode(), target.hashCode());
    }
}