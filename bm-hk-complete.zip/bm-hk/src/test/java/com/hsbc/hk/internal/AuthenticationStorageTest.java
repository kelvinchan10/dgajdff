package com.hsbc.hk.internal;

import com.hsbc.hk.AuthenticationService;

import static org.junit.jupiter.api.Assertions.*;

class AuthenticationStorageTest {
    private AuthenticationStorage target = null;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        target = new AuthenticationStorage();
    }

    @org.junit.jupiter.api.Test
    void testGetTokenUserMap() {
        assertNotNull(target.getTokenUserMap());
        assertEquals(0, target.getTokenUserMap().size());
    }

    @org.junit.jupiter.api.Test
    void testGetNameRoleMap() {
        assertNotNull(target.getNameRoleMap());
        assertEquals(0, target.getNameRoleMap().size());
    }

    @org.junit.jupiter.api.Test
    void testGetNameUserMap() {
        assertNotNull(target.getNameUserMap());
        assertEquals(0, target.getNameUserMap().size());
    }
}