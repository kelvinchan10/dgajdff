package com.hsbc.hk.internal;

import static org.junit.jupiter.api.Assertions.*;

class UserObjectTest {
    private UserObject target = null;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        target = new UserObject("Peter", "123456");
    }

    @org.junit.jupiter.api.Test
    void testName() {
        assertEquals("Peter", target.name());
        assertNotEquals("Pe", target.name());
    }

    @org.junit.jupiter.api.Test
    void testAuthenticated() {
        assertFalse(target.authenticated("2345"));
        assertTrue(target.authenticated("123456"));
    }

    @org.junit.jupiter.api.Test
    void testGetRoles() {
        assertNotNull(target.getRoles());
        assertEquals(0, target.getRoles().size());
    }

    @org.junit.jupiter.api.Test
    void testEquals() {

        assertTrue(target.equals(new UserObject("Peter", "123456")));
        assertTrue(target.equals(new UserObject("Peter", "1234567")));
        assertFalse(target.equals(new UserObject("Pete", "123456")));
    }

    @org.junit.jupiter.api.Test
    void testHashCode() {
        assertEquals(new UserObject("Peter", "123456").hashCode(), target.hashCode());
        assertEquals(new UserObject("Peter", "1234567").hashCode(), target.hashCode());
        assertNotEquals(new UserObject("Pete", "123456").hashCode(), target.hashCode());
    }
}